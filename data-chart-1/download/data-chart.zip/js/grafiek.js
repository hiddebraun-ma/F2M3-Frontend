const startGrafiek = () => {
    // Hier komt de jouw code die na het laden van de pagina wordt uitgevoerd
}

const laadJSON = (url) => {
   // Hier komt de code die gegevens uit een JSON bestand gaat laden
   
}

const maakGrafiek = () => {
    // Hier gaan we de chart maken

}

// Wacht tot de pagina is geladen, dan pas de startGrafiek functie uitvoeren
window.addEventListener('DOMContentLoaded', startGrafiek);